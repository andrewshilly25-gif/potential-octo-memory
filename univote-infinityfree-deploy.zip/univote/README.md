# Univote Deployment Guide for InfinityFree
1. Extract univote-infinityfree-deploy.zip to htdocs
2. Configure backend/PHP settings
3. Database (univote.db) includes all demo and student records.