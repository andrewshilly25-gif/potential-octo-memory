// Univote Server Entry Point
const express = require("express");
const app = express();

app.use(express.static("public"));
app.listen(3000, () => console.log("Univote running on port 3000"));